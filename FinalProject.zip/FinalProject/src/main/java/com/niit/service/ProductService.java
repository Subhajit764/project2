package com.niit.service;

import java.util.List;

import com.niit.model.Product;

public interface ProductService {
	
	 public boolean SaveProduct(Product pro);  
	 public List<Product> getProducts();  
	 public boolean DeleteProduct(Product pro);  
	 public List<Product> getProductByID(Product pro);  
	 public boolean UpdateProduct(Product pro);
}
