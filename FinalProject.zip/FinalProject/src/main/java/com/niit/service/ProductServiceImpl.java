package com.niit.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.niit.dao.ProductDao;
import com.niit.model.Product;

@Service
@Transactional
public class ProductServiceImpl implements ProductService{

	
	@Autowired
	private ProductDao productDao;
	
    @Override  
    public boolean SaveProduct(Product pro) {  
        return productDao.SaveProduct(pro);  
    }  
  
    @Override  
    public List<Product> getProducts() {  
        return productDao.getProducts();  
    }  
  
    @Override  
    public boolean DeleteProduct(Product pro) {  
        return productDao.DeleteProduct(pro);  
    }  
  
    @Override  
    public List<Product> getProductByID(Product pro) {  
        return productDao.getProductByID(pro);  
    }  
  
    @Override  
    public boolean UpdateProduct(Product pro) {  
        return productDao.UpdateProduct(pro);  
    }

  
}
