package com.niit.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.niit.model.Product;

@Repository
public class ProductDaoImpl implements ProductDao{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public boolean SaveProduct(Product pro) {
		 boolean status=false;  
	        try {  
	            sessionFactory.getCurrentSession().save(pro);  
	            status=true;  
	        } catch (Exception e) {  
	            e.printStackTrace();  
	        }  
	        return status;  
		
	}
	
	@Override
	public boolean DeleteProduct(Product pro) {
		boolean status=false;  
        try {  
            sessionFactory.getCurrentSession().delete(pro);  
            status=true;  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
        return status;  
		
	}
	
	@Override
	public List<Product> getProductByID(Product pro){
		  Session currentSession = sessionFactory.getCurrentSession();  
	        Query<Product> query=currentSession.createQuery("from Product where Id=:Id", Product.class);  
	        query.setParameter("Id", pro.getId());  
	        List<Product> list=query.getResultList();  
	        return list;  
	}
	
	@Override
	public boolean UpdateProduct(Product pro) {
		boolean status=false;
		try
		{
			sessionFactory.getCurrentSession().update(pro);
			status=true;
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;	
	}
	
	@Override
	public List<Product> getProducts()
	{
		Session currentSession = sessionFactory.getCurrentSession();
		Query<Product> query=currentSession.createQuery("from Product",Product.class);
		List<Product> list = query.getResultList();
		return list;
		
	}

}
