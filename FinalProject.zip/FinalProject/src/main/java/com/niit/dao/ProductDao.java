package com.niit.dao;

import java.util.List;

import com.niit.model.Product;

public interface ProductDao {
	
	public boolean SaveProduct(Product pro); 
	public boolean DeleteProduct(Product pro);  
	public List<Product> getProductByID(Product pro);
	public boolean UpdateProduct(Product pro);
	public List<Product> getProducts();

}
