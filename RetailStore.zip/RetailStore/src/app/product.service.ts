import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private baseUrl = 'http://localhost:8100/Product';

  constructor(private http: HttpClient) { }

  getProductList(): Observable<any> {  
    return this.http.get(`${this.baseUrl}/products`);  
  }  
  
  CreateProduct(product: object): Observable<object> {  
    return this.http.post(`${this.baseUrl}/save`, product);  
  }  
  
  DeleteProduct(Id: number): Observable<any> {  
    return this.http.delete(`${this.baseUrl}/delete/${Id}`, { responseType: 'text' });  
  }  
  
  getProduct(Id: number): Observable<any> {  
    return this.http.get(`${this.baseUrl}/product/${Id}`);  
  }  
  
  UpdateProduct(Id: number, value: any): Observable<Object> {  
    return this.http.post(`${this.baseUrl}/update/${Id}`, value);  
  }  
}
