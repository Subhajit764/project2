export class Product {
    Id: number;
    Name: string;
    Price:number;
    active: boolean;
    retrievedImage: string;
    isAdded: boolean;
}